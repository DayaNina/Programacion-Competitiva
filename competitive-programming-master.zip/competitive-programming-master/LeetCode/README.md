# LeetCode

First time usage

```sh
npm install -g leetcode-cli
# login
leetcode user -l
```

## Regular training

Download a problem with

```sh
leetcode show [problem-id] -g -l cpp
```

