#include <bits/stdc++.h>
using namespace std;

#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define F(i,a) FOR(i,0,a)
#define MS(a, v) memset(a, v, sizeof a)
#define NL printf("\n")
#define INF 1e9
#define PI acos(-1)
#define EPS 1e-9
#define TR(ar, it) for ( typeof(ar.begin()) it = ar.begin(); it != ar.end(); it++ )

typedef long long LL;
typedef pair<int, int> pii;
typedef vector<int> vi;

int is_anagram(string L, string M) {
	map<char, int> m;
	for (char &c: L) {
		m[c]++;
	}

	for (char &c: M) {
		auto it = m.find(c);
		if (it != m.end()) {
			it->second--;
			if (it->second == 0) {
				m.erase(it);
			}
		}
	}
	return m.empty();
}

int main() {
	cout << is_anagram("abc", "def") << endl;
	cout << is_anagram("ab", "adsdfsdfdb") << endl;
	cout << is_anagram("  ", "df s ") << endl;
	return 0;
}