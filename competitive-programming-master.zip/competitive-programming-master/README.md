# Competitive programming

> My adventures on online judges

I've solved around ~1.5k problems on different online judges while practicing for the ACM-ICPC contest a while ago, even though I don't compete that often anymore I'm always trying to participate on contests to keep my memory fresh.

UVa is my main platform to practice, I've solved more than 1k problems over there, this is my profile http://uhunt.onlinejudge.org/id/55889

Some problems are a variation of a well known algorithm, I have templates for some of them stored inside `_template`

## Other awesome repositories

- https://github.com/marioyc/Online-Judge-Solutions
- https://github.com/lnishan/awesome-competitive-programming
